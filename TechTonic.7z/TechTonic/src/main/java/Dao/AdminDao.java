package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import conections.GetConnection;
import pojo.MyTechPojo;
import pojo.TechPojo;

public class AdminDao 
{

	Connection con = null;
	
	public ArrayList<MyTechPojo> getByTital(String tital1) throws SQLException
	{
		System.out.println("i am hoooooooooooooooooooooooooo1111111111111");
		ArrayList<MyTechPojo> l1 = new ArrayList<MyTechPojo>();
		con =  GetConnection.getConnection();
		/*Statement stmt=con.createStatement();
		String query = "SELECT dateOfLacture,tital,discription,prasentator FROM TechDetail" ;
		ResultSet rst = stmt.executeQuery(query);*/
		
		
		PreparedStatement stmt = con.prepareStatement("SELECT * FROM MyTechDetail where tital='"+tital1+"'");
		ResultSet rst= stmt.executeQuery();
		
		
		//System.out.println("i am hoooooooooooooooooooooooooo22222222222222222222");
		
		while(rst.next())
		{
			
			String dateOfLecture = rst.getDate("dateOfLacture")+"";
			String tital = rst.getString("tital");
			String discription = rst.getString("discription");
			String prentator = rst.getString("prasentator");
			//String interested = rst.getString("interested");
			String email = rst.getString("email");
			System.out.println(dateOfLecture);
			l1.add(new MyTechPojo(dateOfLecture, tital, discription, prentator,"interested",email));
			
		}
		
		con.close();
		return l1;
		
	}
	
	public int addticTock(TechPojo t1) throws SQLException
	{
		con =  GetConnection.getConnection();
		Statement stmt=con.createStatement();
		String dateOfLacture = t1.getDateOfLecture();
		String tital = t1.getTital();
		String description = t1.getDiscription();
		String presentator = t1.getPrentator();
		String query = "INSERT INTO TechDetail values( TO_DATE ( '"+dateOfLacture+"','MM-DD-YYYY' ),'"+tital+"','"+description+"','"+presentator+"','N')";

		System.out.println(query);
		int result = stmt.executeUpdate(query);
		con.commit();
		con.close();
		
		return result;
	
	}
	
	public int updatetachtalk(TechPojo p_new,TechPojo p_pre) throws SQLException
	{
		String dateOfLecture_new = p_new.getDateOfLecture();
		String tital_new = p_new.getTital();
		String discription_new = p_new.getDiscription();
	
		String prentator_new = p_new.getPrentator();
		
		String dateOfLecture_pre = p_pre.getDateOfLecture();
		String tital_pre = p_pre.getTital();
		String discription_pre = p_pre.getDiscription();
		System.out.println(discription_pre);
		String prentator_pre = p_pre.getPrentator();
		
		con =  GetConnection.getConnection();
		Statement stmt=con.createStatement();
		
		String query = "update TechDetail set dateOfLacture=TO_DATE ( '"+dateOfLecture_new+"','YYYY-MM-DD' ),tital='"+tital_new+"',discription='"+discription_new+"',prasentator='"+prentator_new+"' where "
					+ "dateOfLacture=TO_DATE ( '"+dateOfLecture_pre+"','YYYY-MM-DD' ) AND tital='"+tital_pre+"'AND discription='"+discription_pre+"'AND prasentator='"+prentator_pre+"'";
		
		System.out.println(query);
		int result = stmt.executeUpdate(query);
		con.commit();
		con.close();
		
		return result;
		
		
	}

	public int deletetachtalk(TechPojo p_new) throws SQLException
	{
		con =  GetConnection.getConnection();
		Statement stmt=con.createStatement();
		
		String dateOfLecture_new = p_new.getDateOfLecture();
		String tital_new = p_new.getTital();
		String discription_new = p_new.getDiscription();
	
		String prentator_new = p_new.getPrentator();
		String query="delete from TechDetail where dateOfLacture=TO_DATE ( '"+dateOfLecture_new+"','YYYY-MM-DD' ) AND tital='"+tital_new+"'AND discription='"+discription_new+"'AND prasentator='"+prentator_new+"'";
		int result = stmt.executeUpdate(query);
		con.commit();
		con.close();
		
		return result;
	}
	
	
}
