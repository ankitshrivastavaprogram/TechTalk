package pages;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Dao.AdminDao;
import pojo.TechPojo;


public class UpdateTachTalkServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		servrequest(request, response);
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		servrequest(request, response);
	}
	
	protected void servrequest(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException
	{
		
		String dateOfLecture = request.getParameter("date");
		String tital = request.getParameter("tital");
		String discription = request.getParameter("description");
		String prentator = request.getParameter("prasentator");
		
		String dateOfLecture_pre = request.getParameter("date_pre");
		String tital_pre = request.getParameter("tital_pre");
		String discription_pre = request.getParameter("description_pre");
		String prentator_pre = request.getParameter("prasentator_pre");
		
		TechPojo p_new = new TechPojo(dateOfLecture, tital, discription, prentator);
		TechPojo p_pre = new TechPojo(dateOfLecture_pre, tital_pre, discription_pre, prentator_pre);
		AdminDao d1 = new AdminDao();
		
				try {
					d1.updatetachtalk(p_new, p_pre);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
				RequestDispatcher rd = request.getRequestDispatcher("AdminServletWellcome");
				rd.forward(request, response);
		
	}

}
