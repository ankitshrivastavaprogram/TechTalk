package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Dao.EmployeeDao;
import pojo.Employees_pojo;

/**
 * Servlet implementation class SignupServlet1
 */
public class SignupServlet1 extends HttpServlet {
	

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		servrequest(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		servrequest(request, response);
		
	}

	protected void servrequest(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException
	{
		
		
		String email = request.getParameter("email");
		String name =  request.getParameter("name");
		String password =  request.getParameter("password");
		System.out.println(email);
		Employees_pojo p1 = new Employees_pojo(email, name, password);
		EmployeeDao d1 = new EmployeeDao();
		boolean registrationstatus=false;
		try {
			 registrationstatus = d1.registerEmployee(p1);
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		PrintWriter out = response.getWriter();
		if(registrationstatus)
			response.sendRedirect("Login.jsp");
		else
			
			//out.println("you are not registeredd");
			
	    
			response.sendRedirect("signupjs2.jsp");
		
	}
	
}
