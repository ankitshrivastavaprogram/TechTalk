package pages;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Dao.AdminDao;
import pojo.TechPojo;


public class AddTachTalkServlet extends HttpServlet {
	
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		servrequest(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		servrequest(request, response);
	}

	protected void servrequest(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException
	{
		String dateOfLecture = request.getParameter("date");
		String tital = request.getParameter("tital");
		String discription = request.getParameter("description");
		String prentator = request.getParameter("prasentator");
		TechPojo p_new = new TechPojo(dateOfLecture, tital, discription, prentator);
		AdminDao d1 = new AdminDao();
		
		try {
			d1.addticTock(p_new);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		RequestDispatcher rd = request.getRequestDispatcher("AdminServletWellcome");
		rd.forward(request, response);
	}
}
