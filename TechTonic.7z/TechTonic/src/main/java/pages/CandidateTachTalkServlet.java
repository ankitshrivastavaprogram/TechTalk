package pages;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.AdminDao;
import Dao.EmployeeDao;
import pojo.MyTechPojo;
import pojo.TechPojo;

/**
 * Servlet implementation class CandidateTachTalkServlet
 */
public class CandidateTachTalkServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		servrequest(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		servrequest(request, response);
	}

	
	protected void servrequest(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException
	{
		HttpSession session = request.getSession();
		if(session.getAttribute("email")==null||session.getAttribute("password")==null)
				{
			
			response.sendRedirect("index.jsp");
			
			
				}
		
		else
		{
	AdminDao d1 = new AdminDao();
		try {
			
			String tital = request.getParameter("tital");
			ArrayList<MyTechPojo>l1 = d1.getByTital(tital);
			request.setAttribute("listnew", l1);
			System.out.println("zzzzzzzzzzzzzzzzzzzzzzzzz8888888888888888888888888zz"+tital);
			RequestDispatcher rd = request.getRequestDispatcher("tableOfcandidate.jsp");
			//System.out.println("zzzzzzzzzzzzzzzzzzzzzzzzzzz");
			rd.forward(request, response);
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}
	
	}
}
