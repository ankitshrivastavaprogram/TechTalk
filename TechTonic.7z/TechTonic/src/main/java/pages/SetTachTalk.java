package pages;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.EmployeeDao;
import pojo.MyTechPojo;
import pojo.TechPojo;


public class SetTachTalk extends HttpServlet {
	
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		servrequest(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		servrequest(request, response);
	}

	protected void servrequest(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException
	{
		HttpSession session = request.getSession();
		
		String dateOfLecture = request.getParameter("date");
		String tital = request.getParameter("tital");
		String discription = request.getParameter("description");
		String prentator = request.getParameter("prasentator");
		 String interested = request.getParameter("interested");
		String email = session.getAttribute("email").toString();
		MyTechPojo p_my = new MyTechPojo(dateOfLecture, tital, discription, prentator,email);
		EmployeeDao d1 = new EmployeeDao();
		try {
			d1.addtomytechdetail(p_my);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		RequestDispatcher rd = request.getRequestDispatcher("EmployeeServletWellcome");
		rd.forward(request, response);
		
	}
}
